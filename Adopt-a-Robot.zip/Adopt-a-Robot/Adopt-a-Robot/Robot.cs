﻿namespace Adopt_a_Robot
{
    class Robot
    {
        public string Name;
        public string Color;

        public Robot(string name, string color)
        {
            Name = name;
            Color = color;
        }
    }
}