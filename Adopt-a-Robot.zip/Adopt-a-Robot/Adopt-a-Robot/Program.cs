﻿/* Adopt A Robot
 * Example code for PROG 101
 * Originally created by Janell Baxter
 * Game class refactored by _______________
 * Summer 2021
 */


namespace Adopt_a_Robot
{
    class Program
    {
        static void Main(string[] args)
        {
            Game game = new Game("Super Awesome Adopt-a-Bot Game!");
            game.Start();
        }
    }
}