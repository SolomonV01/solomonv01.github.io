﻿using System;
using static System.Console;

/* Original Game by Solomon Vidal
 * A Reader's Guide to Being Y/N
 * Midterm Prototype
 * Fall 2022
 */

namespace Vidal_Midterm_Prototype
{
    class Program
    {
        static void Main(string[] args)
        {
            WriteLine("Welcome to A Reader's Guide to Being Y/N!");

            ReadLine();
        }
    }
}

