﻿using System;
using Vidal_Game_Prototype;
using static System.Console;

namespace Vidal_Game_Prototype
{
    class Game
    {

        public Player player;
        public string? Name {get; set;}

        public Items Sword = new Items("Sword");
        public Items Dice = new Items("Dice");
        public Items Rose = new Items("Rose");

        public void name()
        {
            WriteLine("What is your name?");
            Name = ReadLine();

            player = new Player(Name);
        }
    
        public void gameTitle()
        {
            WriteLine($"Hello, {player.Name}");
            WriteLine(" ");

            WriteLine("Welcome to 'A Beginner's Guide to Being Y/N'.");
            WriteLine(" ");

            WriteLine("Press 'Enter' to begin your journey.");
            ReadLine();
            Clear();
            first();
        }
        public string? Side_Characters { get; set; }

        public void sideCharacters()
        {
            string[] sideCharacters = new string[3];

            sideCharacters[0] = "Ozret";
            sideCharacters[1] = "Riza";
            sideCharacters[2] = "Lanidrac";
            sideCharacters[3] = "Luria";

        }
        public void first()
        {
            //Day 1

            string choice;

            WriteLine("You abruptly wake up to a pounding headache eyes matched with a blinding brightness. The sounds you hear aren't the ususal bustle of city life. \nIt's the sound of birds, crickets, and cicadas. You wait until your headache subsides and get up. \nYou notice that you've been laying in straw inside of, what seems to be, a stable. A girl walks in and jumps. 'They're awake!' she yells. ");

            WriteLine(" ");

            WriteLine("What do you do?");

            WriteLine(" ");

            WriteLine("1. Run after her.");
            WriteLine(" ");

            WriteLine("2. Wait in the stable.");
            WriteLine(" ");

            WriteLine("3. Try to run away.");
            WriteLine(" ");

            Write("Choice: ");
            choice = ReadLine().ToLower();
            Clear();

            switch (choice)
            {
                case "1":
                case "run after her":
                case "Run after her":
                case "run":
                case "Run":

                    {
                        WriteLine("You make a break for it and run after her. ");
                        WriteLine(" ");

                        WriteLine("The girl is startled even more, screams, and runs inside of a brick house. ");
                        WriteLine(" ");

                        WriteLine("'Wait!' you call out 'Who are you?' You follow her into the house only to be met with a wall. ");

                        WriteLine("The wall, however, is warm and smells like evergreens. You look up and see a tall man who's smiling, but you can tell they're displeased. ");
                        WriteLine(" ");

                        WriteLine("'I see your first reaction to meeting people is to chase them down...' the man frowns. ");
                        WriteLine(" ");

                        WriteLine("You laugh awkwardly and respond, 'I apologize...'. ");

                        WriteLine("The man doesn't laugh and stares at you in contempt. \n'You aren't the hero we need.' he grumbles, disappointed, before throwing you out into the wilderness.");
                        WriteLine(" ");

                        WriteLine("Press 'Enter' to continue.");
                        ReadLine();
                        gameOver();
                        break;

                    }
                case "2":
                case "Wait in the stable":
                case "wait in the stable":
                case "wait":
                case "Wait":
                    {
                        WriteLine("You decide to wait patiently at the stables. ");

                        WriteLine("This place is unfamiliar to you and you're about just as shocked to see that girl as she was to see that you were awake. ");
                        WriteLine(" ");

                        WriteLine("You hear rustling outside and you see a tall, salt and pepper haired, man wearing a white lace-up shirt with black breeches. ");

                        WriteLine("'It seems like our nameless guest has awoken' the man smiles. \nHe looks... familiar, but you can't quite make out why... ");
                        WriteLine(" ");

                        WriteLine($"'I'm not nameless...' you correct him, 'My name is '{Name}. ");
                        WriteLine(" ");

                        WriteLine($"Alright, {Name}; nice to meet you. My name is Lanidrac.' he smiles. ");

                        WriteLine("Your mouth is left agape. That's why he seemed so familiar even though you haven't met him before. ");

                        WriteLine("Press 'Enter' to continue. ");
                        ReadLine();
                        firstDialogue();
                        break;
                    }
                case "3":
                case "run away":
                case "Run away":
                case "Try to run away":
                case "try to run away":        
                    {
                        WriteLine("You decide to run away. ");

                        WriteLine(" ");

                        WriteLine("This place has to be filled with people you don't know. ");

                        WriteLine(" ");

                        WriteLine("Not knowing who has you in their clutches, you decide to run away as fast as you can. ");

                        WriteLine(" ");

                        WriteLine("Before you 'escape' something tugs at your legs causing you to trip and fall. ");

                        WriteLine(" ");

                        WriteLine("'Running away at the first sign of people I see...' you look back towards the voice and see a tall, salt and pepper haired, man wearing a white lace-up shirt with black breeches. \n'My name's Lanidrac. We'll make a hero out of you yet as long as you're as careful as you are.' the man laughs. ");
                        WriteLine(" ");

                        WriteLine("Press 'Enter' to continue. ");
                        ReadLine();
                        firstDialogue();
                        break;
                    }
                default:
                    {
                        WriteLine("Unavailable command... ");

                        WriteLine(" ");

                        WriteLine("Press 'Enter' to try again ");
                        ReadLine();
                        first();
                        break;
                    }

            }   Clear();
            
        }
        public void firstDialogue()
        {
            WriteLine("He's that princely commoner, who's actually a Fae prince from \nthe Forest of Silence in your most current read 'A Kingdom of Storms and Silence' by Jarah M. Saas! \nBut... His lines seem different than the actual book? It sounds more like fanfic- Oh, no... \nYou recollect the last thing you read before you ended up in this \nfictional nightmare: 'A Triangle of Storms and Silence'... a love triangle fanfic... ");
            WriteLine(" ");

            WriteLine("You knew you shouldn't have gotten so desperate as to read a love triangle fanfic! \nWhat are you? 12??? \nAfter sighing to yourself in disappointment, Lurien turns to you and asks 'Are you alright?'. \n'I'm alright' you reply, a bit more upbeat as to hide your embarassment. \nLanidrac smiles 'That's a relief, we wouldn't want you down in the dumps before you've seen anything yet!' \nYou laugh awkwardly. You return to your mind palace and try to remember as much of the story as possible...  ");
            WriteLine(" ");

            WriteLine("Press 'Enter' to continue. ");
            ReadLine();
            storySummary();
            Clear();
        }

        public void storySummary()
        {
            WriteLine("The good thing this tragedy of a fanfic folows closely to the original plot \nof the book except for the absurd amount of self-insert romance added in... \nYou decide to ask Lanidrac about the kingdom to gauge where you are in the timeline of the story. \n'So far, King Ozret has been the ruler for 12 moon rotations \nand the balance of power has been tipped to a grave imbalance.' Lanidrac starts, 'Members of the royal family have been fighting among each other and have caused discord within their respective lands... ' \n'Where does that leave us? The citizens? In poverty and swimming in feelings of disdain. \nSo, to fix that, we're having a rebellion!' \n'He said that way too happily' you think to yourself, 'I doubt Lanidrac knows that Ozret is his older brother at this point in the story... Big Yikes.' \n'Ahem.' Lanidrac clears his throat to grab your attention, \n'How about, instead of talking about important details outside, we can discuss them inside?' \n'You're absolutly correct. Although... are you sure Lu- I mean, that girl won't scream again?' you ask. \n'That was a close one,' you exclaim in your head. 'Now that I know who he is, I almost said another character's name before they've even been formally introduced...' \n'Yes, I'm sure.' he laughs, eyes crinkled and mouth wide. \n'Hard not to fall for this character when they're all shiny even when they laugh' \nyou analyze as you follow Lanidrac to his house. "
                );
            WriteLine(" ");

            WriteLine("Press 'Enter' to continue. ");
            ReadLine();
            theHouse();
            Clear();
        }

        public void theHouse()
        {
            WriteLine("You make your way into the house with Lanidrac\n and you come across the girl who ran away.\n 'This is Lurien' Lanidrac happily introduces his sister. ");
            WriteLine(" ");

            WriteLine($"Nice to meet you, Lurien! My name is {Name}.' you introduce yourself. ");
            WriteLine(" ");

            WriteLine("'I'm sorry we got off on the wrong foot last time- well, earlier...'\n you add, trying to lighten the mood. \n'That's alright! I'm sorry for my reaction earlier...' Lurien apologizes, \n'I've just been anxious nowadays and wary of strangers.'\n 'I can understand why...' you pondered the end of this story \nin the case of your failure. \nIn the heat of the moment (of pondering), you exclaim: \n'I promise I won't let that happen!' \n'What am I doing???' you think, 'There's no way I can guarantee that I can do anything...' ");
            WriteLine(" ");

            WriteLine("Well... now you've been roped into it...");
            WriteLine("Fine! 'I'll go... tomorrow!' you suggest. \n'Where?? Do you know how to get to any of the cities?' Lanidrac asks. \n'I don't know, but I'll figure it out in a sec!' you yell, walking towards the door. \n'I'm part of this anyways so I might as well give it my all' you murmur, before stepping out. ");
            WriteLine(" ");

            WriteLine("You see a city in the distance... It's the closest lead you have to figuring out where you're supposed to go so you head over. ");
            WriteLine(" ");

            WriteLine("'Wait!' Lanidrac yells, running out the door. 'You should take this with' Lanidrac pulls out a thin sword; a rapier! \n'I couldn't possibly take this! It looks way too valuable...' you respond. It's true. The sword looked well polished and unused. ");
            WriteLine("       O ,_\n II    |/  `\nO//////])==============================- \n \\    /|\n  `--~ O");
            WriteLine(" ");

            WriteLine("'Don't worry about it.' Lanidrac assures with a kind smile, 'You'll need it more than I do. Even though there aren't dangers now doesn't mean there aren't any waiting'. ");
            WriteLine(" ");

            WriteLine("You accept the sword, 'Thank you' you smile back before walking towards the nearby town. ");
            player.inventory.Add(Sword);
            WriteLine(" ");

            WriteLine("Press 'Enter' to continue. ");
            ReadLine();
            theTown();

            Clear();
        }

        public string? Items { get; set; } 

        public void theTown()
        {
            string choice;

            WriteLine("You make it to the city and walk around. \nIt's lively even though there's a crisis... \nAfter some travelling, you make your way into a dark alley way. \nIt's dimmer in feel and in look. Speaking of looking, you see a mysterious cloaked villager walking towards you. ");

            WriteLine("'Would you like some dice?' they ask. What an odd voice they have, it's indistinguishable... ");
            WriteLine(" ");

            WriteLine("What do you say? ");
            WriteLine(" ");

            WriteLine("1. Sure, I want the dice. ");
            WriteLine(" ");

            WriteLine("2. No, I don't want your dice. ");
            WriteLine(" ");

            Write("Choice: ");

            choice = ReadLine().ToLower();

            switch (choice)
            {
                case "1":
                case "Sure":
                case "Yes":
                case "yes":
                case "y":
                case "Y":
                    {
                        player.inventory.Add(Dice);
                        WriteLine("You accept the dice from the mysterious stranger. \n'Sure, I wouldn't mind some dice. Thank you!' you thank the stranger \n'No problem' the stranger responds 'You need these dice more than I do and more than you know.' \n'Use them wisely' the stranger smiles before walking away and disappearing into a nearby alleyway. \n'That really was weird...' you think, 'weirder than it was in the book...' \nYou look at the dice and thnk about what they said: 'Use it wisely'. \n'If this fanfic still makes sense, I should be able to travel using the dice!' you cheer quietly. ");
                        WriteLine(" ");

                        WriteLine("You use the dice... ");
                        WriteLine(" ");

                        WriteLine("Press 'Enter' to continue. ");
                        ReadLine();
                        second();
                    }
                    
                    break;
                

                case "2":
                case "no":
                case "No":
                case "n":
                case "N":
                    {
                        WriteLine("You decide not to accept the dice from the stranger \n'No, thank you' you tell the stranger. \n'That's alright' the stranger responds. \n'Good Luck — although, I doubt luck will save you' they add eerily. you continue your quest for a map in the town. ");
                        WriteLine(" ");

                        WriteLine("Press 'Enter' to continue");
                        ReadLine();
                        noDice();
                    }
                    
                    break;
            }

            Clear();
        }
        public void noDice()
        {
            WriteLine("You decide, after walking, through the town that you'll just start your journey without a map. \nPast the city is the wilderness, the only means of getting to Evernight Castle where the tyrant king lives. \nYou head into the wilderness. \nThe path darkens and you are left shivering from the cold. \nUnable to see past the fog, you run into a Evernight Bear who's patrolling. \nThe bear tears you to shreds...");
            WriteLine(" ");

            WriteLine("Evidently... You died. ");
            WriteLine(" ");

            WriteLine("Press 'Enter' to continue");
            ReadLine();
            gameOver();

        }

        public void second()
        {
            //Day 2
            Random rnd = new Random();
            string[] locations = {
                "Evernight Castle ",
                "Forest of Silence ",
                "Evernight City ",
                "Camp Soleil ",
                "Satus Town "
            };
            int randomNumber = rnd.Next(0, 4);
            string secLocations = locations[randomNumber];

            string secChoice;

            WriteLine(secLocations);
            WriteLine("Do you go to " + locations[randomNumber] + "? Yes or No?");
            WriteLine(" ");

            Write("Choice: ");
            secChoice = ReadLine().ToLower();

            if (secChoice == "yes" || secChoice == "Yes")
            {
                third();
                
            }
            else if (secChoice == "no" || secChoice == "No")
            {
                WriteLine("You choose to stay and don't do anything. ");
                WriteLine(" ");

                WriteLine("Without having done anything that day, your chances of defeating the boss decreases by 20%. ");
                WriteLine(" ");

                WriteLine("That is the least of your worries. \nSeeing as you don't plan on helping, the villagers kick you out and you're doomed to die in the wilderness. ");
                WriteLine(" ");

                WriteLine("Press 'Enter' to continue. ");
                ReadLine();
                gameOver();
            }
            else
            {
                WriteLine("Unavailable command... ");
                WriteLine(" ");

                WriteLine("Press 'Enter' to try again. ");
                ReadLine();
                second();
            }
            Clear();

        }
        public void third()
        {

            string choice;

            WriteLine("You travel to another destination. ");
            WriteLine(" ");

            WriteLine("You pass by a wandering swordsman who gives you a side glance. \nBefore you can even think to call him rude in your head, he pulls out his sword. ");
            WriteLine(" ");

            WriteLine("'Do you truly believe you'll be able to defeat the king in your condition? '");
            WriteLine(" ");

            WriteLine("He charges at you with his broad sword. ");
            WriteLine(" ");

            WriteLine("What do you do? ");
            WriteLine(" ");

            WriteLine("1. Charge back at him. ");
            WriteLine(" ");

            WriteLine("2. Scream. ");
            WriteLine(" ");

            WriteLine("3. ??? ");
            WriteLine(" ");

            Write("Choice: ");
            choice = ReadLine().ToLower();
            Clear();

            switch (choice)
            {
                case "1":
                case "Charge":
                case "charge":
                case "charge at him":
                case "Charge at him":
                    {
                        WriteLine("You grab at your waist for the sword given to you by Lanidrac. ");
                        WriteLine(" ");

                        WriteLine("       O ,_\n II    |/  `\nO//////])==============================- \n \\    /|\n  `--~ O");
                        WriteLine(" ");

                        WriteLine("You start fighting the unnamed swordmaster with as much strength as you can muster. \nHe has the upper hand considering he's had more training than you've ever had in your life. \nClanging escapes from your sword as the swordsman continues to hammer his broadsword onto your rapier. \nThe endless ringing echoes into your ears. Your eyes close. You're starting to get annoyed... ");
                        WriteLine(" ");

                        WriteLine("            _\n _         | |\n| | _______| |---------------------------------------------\\\n|:-)_______|==[]============================================>\n|_|        | |---------------------------------------------/\n           |_|");
                        WriteLine(" ");

                        WriteLine("A third, heavy, clang rings from what sounds like a greatsword and you open your eyes to see Lanidrac. \n'Lanidrac!' you exclaim with relief, 'How did you get here?.' \n'I decided to go along with you on your journey. \nA path which leads to the eventual defeat of the tyrant king.' Lanidrac responds. \n'That and I've grown fond of your persistence.' he adds. \nYou feel a warm swell within your chest. With companions like these, \nmaybe life in another world won't be that outrageous. ");
                        WriteLine(" ");

                        WriteLine("                   /}\n                  //\n                 /{     />\n  ,_____________///----/{____________________________________________________\n/|=============|/\\|-----/____________________________________________________\\\n\\|=============|\\/|-----\\____________________________________________________/\n  '~~~~~~~~~~~~~\\\\\\----\\{\n                 \\{     \\>\n                  \\\\\n                   \\}");
                        WriteLine(" ");

                        WriteLine("'I'll be using these magic dice, though...' you tell Lanidrac. \n'Maybe, both of us will teleport if we hold hands!' he suggests, merrily. \n'This is a fanfic alright...' you think witch a scrunched face. \n'Alright, I guess...' you accept out loud, after some quick deliberation. ");
                        WriteLine(" ");

                        WriteLine("Press 'Enter' to continue. ");
                        ReadLine();
                        fourth();

                        break;
                    }

                case "2":
                case "Scream":
                case "scream":
                    {
                        WriteLine("You think you can save the kingdom by screaming? \nPreposterous! ");
                        WriteLine(" ");

                        WriteLine("You didn't think he'd actually kill you... ");
                        WriteLine(" ");

                        WriteLine("The kingdom's peril must be that great. \nThe weak must perish while the strong gain sovreignty. ");
                        WriteLine(" ");

                        WriteLine("Press 'Enter' to continue. ");
                        ReadLine();
                        gameOver();

                        break;
                    }

                case "3":
                case "???":
                case "?":
                    {
                        WriteLine("The shock sends your senses into overdrive. \nYour mind goes blank. ");
                        WriteLine(" ");

                        WriteLine("In a sudden flash of light, you charge at the swordsman with eyes agleam. \nA surge of power surges about you; it fills your body with cold air and surrounds you with unknown elemental energy which you project forward. \nYou launch the swordsman at the trees enough to knock the wind out of him... for a couple of days. ");
                        WriteLine(" ");

                        WriteLine("'You're powerful enough to get rid of the tyrant king, but...' \nthe swordsman stutters, \n'What are you?' \n'Your mom' you think with a snort. ");
                        WriteLine(" ");

                        WriteLine("You escape from your power surge, however, and frown. \n'God that was cringe... I can't believe that function in the story still exists here' you exclaim with disappointment, 'Horrible writing!' ");
                        WriteLine(" ");

                        WriteLine("Like a male lead in a fanfic, Lanidrac comes out of some random bushes. \n'Are you alright?' Lanidrac asks, face filled with worry, 'I heard quite a bit of sound coming from this direction and I came to check... What are you doing here'. \n'Let's just say that that loud sound was because of me getting mad' you sigh, \n'I've got no time to explain, just come with me.' \n'Where are we going' Lanidrac asks as you aggresively take his hand. \n'We're going to the castle,' you answer, 'hopefully these dice will send us straight there and not some random forest!' ");
                        WriteLine(" ");

                        WriteLine("'I just wanna get this over with...' you think and roll the dice again. ");
                        WriteLine(" ");

                        WriteLine("Press 'Enter' to continue. ");
                        ReadLine();
                        fourth();

                        break;
                    }
            }
            Clear();

            
        }
        public void fourth()
        {
            WriteLine("You teleport again and what luck you have... \nYou've teleported straight into a forest... \n'This is the Forest of Silence,' Lanidrac mentions in awe, 'It really is silent!' \nYou stare; a bit dumbfounded at Lanidrac's very obvious observation. \n'Anyways,' you start, 'Why'd the dice have to sned us here? Here I thought we'd fight a king...' \n Lanidrac laugh, 'I suppose we'll save fighting for another day.' ");
            WriteLine(" ");

            WriteLine("You and Lanidrac walk around and take note of your surroundings when suddenly a voice emerges, 'Who walks thoughtlessly in the Forest of Silence?' \nYou jolt and Lanidrac instinctively puts his hands on you shoulders.");
            WriteLine(" ");

            WriteLine("'Sorry' Lanidrac apologizes, before quickly pulling his hands back to his sides, 'I'm used to calming down my sister nowadays and I guess it became second nature...'. ");
            WriteLine(" ");

            WriteLine("'I know darn well bro ain't blushing right now' you squint at Lanidrac... In the middle of a war, bro? Really?' you think. ");
            WriteLine(" ");

            WriteLine("'Anyways, what do you want?' you ask the voice with more annoyance than you expected.");
            WriteLine(" ");

            WriteLine("'I should be asking you that' the voice snidely replies, 'You looking for a way to defeat the king?'");
            WriteLine("'Yes, actually...' you respond");
            WriteLine(" ");

            WriteLine("Solve this riddle then: \nLoveless king in your tower of tyrany, \n What do you desire that garners sympathy? \nYou, broken rose, have you lost your prose? \nWhat will save you but you? ");
            WriteLine(" ");
            riddle();

            Clear();
        }
        public void riddle()
        {
            string choice;

            Write("What saves the king?: ");
            WriteLine(" ");

            WriteLine("Prose?");
            WriteLine(" ");

            WriteLine("Himself?");
            WriteLine(" ");

            WriteLine("A Rose?");
            WriteLine(" ");

            choice = ReadLine().ToLower();
            Clear();

            switch (choice)
            {
                case "1":
                case "Prose":
                case "prose":
                    {
                        WriteLine("'Why in diety's name would he want that? \nCould it be... you're dumb?' the voice mocks your answer...");
                        WriteLine(" ");

                        WriteLine("You frown while tugging at your rapier...");
                        WriteLine(" ");

                        WriteLine("'Ahem,' the voice coughs nervously, 'Would you like to try again?' ");
                        WriteLine(" ");

                        WriteLine("'Absolutely' you comply with a menacing smile. ");
                        WriteLine(" ");

                        WriteLine("Try Again? If 'yes', press 'Enter' to continue. If 'No', delete your game.' ");
                        ReadLine();
                        riddle();
                    }
                    break;

                case "2":
                case "Himself":
                case "himself":
                    {
                        WriteLine("'Not exactly the correct answer, but close enough!' the voice seems to shrug. \n'Here. Take this.' they speak again and a rose comes flying at you. ");
                        WriteLine(" ");

                        WriteLine("  /-_-\\\n /  /  \\\n/  /    \\\n\\  \\    /\n \\__\\__/\n    \\\\\n    -\\\\    ____\n      \\\\  /   /\n____   \\\\/___/\n\\   \\ -//\n \\___\\//-\n    -//\n     \\\\\n     //\n    //-\n  -//\n  //\n  \\\\\n   \\\\");
                        WriteLine();

                        WriteLine("'You couldn't have given it to me any other way?' you ask with a dead pan face. ");
                        WriteLine(" ");

                        WriteLine("'Not unless you want me to crumble and return to the land. I'm cursed to stay hidden' the voice grows quiet");
                        WriteLine(" ");

                        WriteLine("'Sorry for bringing back some bad memories...' you apologize before thanking the voice. ");
                        WriteLine(" ");

                        WriteLine("'It's no problem... Just make sure you pay the person who cursed me a visit and get him to undo it' the voice hints at your inevitable destination and you nod.");
                        WriteLine(" ");

                        WriteLine("You look to Lanidrac who's finally out of his 'male lead blushing phase' and he nods in understanding. \n'Please let the dice work this time!' you wish in your head.");
                        WriteLine(" ");

                        WriteLine("You roll the dice again");
                        player.inventory.Add(Rose);

                        WriteLine("Press 'Enter' to continue. ");
                        ReadLine();
                        
                    }
                    break;

                case "3":
                case "rose":
                case "Rose":
                case "A rose":
                case "A Rose":
                case "a rose":
                    {
                        WriteLine("'You guessed right!!' the voice cheers, 'You're a smart one aren't you?'");
                        WriteLine(" ");

                        WriteLine("'Here! Take this!' the voice yells before a rose comes flying at you. ");
                        WriteLine(" ");

                        WriteLine("  /-_-\\\n /  /  \\\n/  /    \\\n\\  \\    /\n \\__\\__/\n    \\\\\n    -\\\\    ____\n      \\\\  /   /\n____   \\\\/___/\n\\   \\ -//\n \\___\\//-\n    -//\n     \\\\\n     //\n    //-\n  -//\n  //\n  \\\\\n   \\\\");
                        WriteLine();

                        WriteLine("'You couldn't have given it to me any other way?' you ask with a dead pan face. ");
                        WriteLine(" ");

                        WriteLine("'Not unless you want me to crumble and return to the land. I'm cursed to stay hidden' the voice grows quiet");
                        WriteLine(" ");

                        WriteLine("'Sorry for bringing back some bad memories...' you apologize before thanking the voice. ");
                        WriteLine(" ");

                        WriteLine("'It's no problem... Just make sure you pay the person who cursed me a visit and get him to undo it' the voice hints at your inevitable destination and you nod.");
                        WriteLine(" ");

                        WriteLine("You look to Lanidrac who's finally out of his 'male lead blushing phase' and he nods in understanding. \n'Please let the dice work this time!' you wish in your head.");
                        WriteLine(" ");

                        WriteLine("You roll the dice again");
                        player.inventory.Add(Rose);

                        WriteLine("Press 'Enter' to continue. ");
                        ReadLine();
                        fifth();
                    }
                    break;
            
            }

        }

        public void fifth()
        {
            WriteLine("You appear in a dark hallway...");
            WriteLine(" ");

            WriteLine("'Where are we?' You ask Lanidrac. \n'The dice worked' he stares down the hallway. ");
            WriteLine(" ");

            WriteLine("               T~~\n               |\n              /\"\\\n      T~~     |'| T~~\n  T~~ |    T~ WWWW|\n  |  /\"\\   |  |  |/\\T~~\n /\"\\ WWW  /\"\\ |' |WW|\nWWWWW/\\| /   \\|'/\\|/\"\\\n|   /__\\/]WWW[\\/__\\WWWW\n|\"  WWWW'|I_I|'WWWW'  |\n|   |' |/  -  \\|' |'  |\n|'  |  |LI=H=LI|' |   |\n|   |' | |[_]| |  |'  |\n|   |  |_|###|_|  |   |\n'---'--'-/___\\-'--'---'");
            WriteLine(" ");

            WriteLine("'So... We've arrived...' you hum, 'Do you know where we are exactly?' \n'Not exactly...' Lanidrac explains, 'I've never actually been here before.' ");
            WriteLine(" ");

            WriteLine("Suddenly, you feel a hit to the back of your neck and you pass out. \nThe last thing you hear is Lanidrac yell in anger, 'Ozret!!'");
            WriteLine(" ");

            WriteLine("Press 'Enter' to continue. ");
            ReadLine();
            sixth();

        }
        public void sixth()
        {
            WriteLine("You wake up to grey skies. It seems like morning has arrived, but the skies of the castle prevent light from entering the grounds. ");
            WriteLine(" ");

            WriteLine("'You're finally awake.' a voice emerges from the doorway. \nYou can already tell... The voice belongs to: \n'Ozret' you say, aloud. ");
            WriteLine("'So you know who I am already?'");
            WriteLine(" ");

            WriteLine("'Hard not to... You're infamous' you sigh. \nOzret grows a large frown. \n'I didn't do anything...' he mumbles. ");
            WriteLine(" ");

            WriteLine("'That's not what I meant' you sympathize. \n'What do you mean, then?' he questions. ");
            WriteLine(" ");

            WriteLine("'I mean, I know your story already. I want to make a deal.' you propose. \n'A deal?' he adds. ");
            WriteLine(" ");

            WriteLine("'Yes, a deal. I'll set you free and you send me home. Easy!' you smile. \n'Yeah, if I knew where you lived!' he laughs, unimpressed by the idea. ");

            WriteLine("'Easy. I live on Earth. Just send me there and I'll figure it out.' you request in a hurry.");
            WriteLine(" ");

            WriteLine("'Sure. But you have to help me-' Ozret starts, but you cut him off \n'Catch' you say as you throw the rose at Ozret.");
            WriteLine("'This is a wishing rose... I haven't seen one of these since-' Ozret starts, \n'Since you wished to rule the kingdom' you finish his sentence, face grim. \n'Yeah...' he looks down.");
            WriteLine("               T~~\n               |\n              /\"\\\n      T~~     |'| T~~\n  T~~ |    T~ WWWW|\n  |  /\"\\   |  |  |/\\T~~\n /\"\\ WWW  /\"\\ |' |WW|\nWWWWW/\\| /   \\|'/\\|/\"\\\n|   /__\\/]WWW[\\/__\\WWWW\n|\"  WWWW'|I_I|'WWWW'  |\n|   |' |/  -  \\|' |'  |\n|'  |  |LI=H=LI|' |   |\n|   |' | |[_]| |  |'  |\n|   |  |_|###|_|  |   |\n'---'--'-/___\\-'--'---'");
            WriteLine(" ");

            WriteLine("'Wait!' a voice calls out. Lanidrac. Right when you were about to go home... \nYou decide to speedrun the story for them. ");
            WriteLine(" ");

            WriteLine("'You're brothers. Lanidrac, your older brother made kind of a dumb wish which is why the world is in shambles. \nDon't kill him, but don't let him off the hook. \nDon't ask me any questions right now either; ask each other the questions. Now, send me back so y'all can have family bonding time' you've never spoken so fast in your life.");
            WriteLine(" ");

            WriteLine("Alright, I'll send you back... Then, I'll explain to my apparent brother what's been going on in our family... \nOzret sparkles, makes you sparkle, then your eyes are blinded by the light.");
            WriteLine(" ");

            WriteLine("You wake up in your room and look at your phone... \n'I knew that fanfic was gonna be shi-'");
            WriteLine(" ");

            youWin();
        }
        public void gameOver()
        {
            Clear();
            WriteLine(@" __| |____________________________________________| |__
(__   ____________________________________________   __)
   | |                                            | |
   | |                                            | |
   | |                                            | |
   | |                 You Lost!                  | |
   | |                                            | |
   | |                                            | |
 __| |____________________________________________| |__
(__   ____________________________________________   __)
   | |                                            | |");
            WriteLine(" ");

            WriteLine("You've failed to save the Kingdom...");
            WriteLine(" ");

            WriteLine("Choose more carefully next time.");
            WriteLine(" ");

            WriteLine("Press 'Enter' to try again.");
            ReadLine();
            Clear();
            gameTitle();
        }
        public void youWin()
        {
            Clear();
            WriteLine(@" __| |____________________________________________| |__
(__   ____________________________________________   __)
   | |                                            | |
   | |                                            | |
   | |                                            | |
   | |                  You Won!                  | |
   | |                                            | |
   | |                                            | |
 __| |____________________________________________| |__
(__   ____________________________________________   __)
   | |                                            | |");
            WriteLine(" ");

            WriteLine("You've saved the Kingdom! By... being y/n. The thing about being y/n is that nothing makes sense. \nThe power of y/n isn't something magical, it's that y/n can have any ending they want. \nEven if it doesn't make a lick of sense.");
            WriteLine(" ");

            WriteLine("Press 'Enter' to try a different path.");
            ReadLine();
            Clear();
            gameTitle();
        }
    }
}





    





