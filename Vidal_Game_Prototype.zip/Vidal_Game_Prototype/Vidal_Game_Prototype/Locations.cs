﻿using System;
using static System.Console;

namespace Vidal_Game_Prototype
{
    public class Locations
    {
        private int i;
        public string? currentLocation;

        public string[] locations = {
                "Evernight Castle",
                "Forest of Silence",
                "Evernight City",
                "Camp Soleil",
                "Satus Town"
        };

        public Locations()
        {

            Random rnd = new Random();
            int randomNumber = rnd.Next(0, 4);


            WriteLine($"You head to {locations[randomNumber]}");
            ReadKey();

            if (randomNumber == 0)
            {
                WriteLine("You head to Evernight Castle");

            }
            else if (randomNumber == 1)
            {
                WriteLine("You head to the Forest");
            }
            else if (randomNumber == 2)
            {
                WriteLine("You head to Evernight City");
            }
            else if (randomNumber == 3)
            {
                WriteLine("You head to Camp Soleil");
            }
            else if (randomNumber == 4)
            {
                WriteLine("You head to Satus Town");
            }
            else 
            {
                WriteLine("That place doesn't exist...");
            }

        }

    }
}

