﻿using System;
using Vidal_Game_Prototype;
using static System.Console;

//Game by Solomon Vidal
//Broadsword ASCII Art by Shawn Leas
//Rapier Sword ASCII Art by Alvin Sayanna
//Great Sword ASCII Art by Christopher Weible
//Rose Art by Joan G. Stark
//Castle Art by Unknown (on ASCII Archive)
//Videos I watched for practice: FreeCodeCamp "C#" lessons and "ASCII Art" by Michael Hadley
//Credit to Grace Anders for helping me with my randomized code, my .add portions, and helping me fix my code.

namespace Vidal_Game_Prototype
{
    class Program
    {
        //new Game();

        static void Main(string[] args)
        {
            Game game = new Game();
            game.name();
            game.gameTitle();
            game.first();
            game.firstDialogue();

            Locations locations = new Locations();

            Side_Characters side_Characters = new Side_Characters();

            ReadLine();
            Clear();
        }
    }
}

