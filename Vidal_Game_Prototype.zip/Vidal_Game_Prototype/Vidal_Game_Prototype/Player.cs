﻿using System;
using static System.Console;

namespace Vidal_Game_Prototype
{
    public class Player
    {
        public string Name { get; private set; }
        public Player(string name)
        {
            Name = name;
        }

        public List<Items> inventory = new List<Items>();
    }
}

