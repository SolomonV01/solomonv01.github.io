﻿using System;
namespace Vidal_Game_Prototype
{
    public class Items
    {
        string name;
        string description;

        public Items(string Name, string Description)
        {
            name = Name;
            description = Description;
        }

        public Items(string Name)
        {
            name = Name;
           
        }

    }
}

