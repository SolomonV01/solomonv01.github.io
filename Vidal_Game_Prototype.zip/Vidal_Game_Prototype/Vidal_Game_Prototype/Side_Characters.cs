﻿using System;
using static System.Console;
using static System.Net.Mime.MediaTypeNames;

namespace Vidal_Game_Prototype
{
    public class Side_Characters
    {
        public void sideCharacters()
        {
            string[] sideCharacters = new string[3];
            sideCharacters[0] = "Ozret";
            sideCharacters[1] = "Riza";
            sideCharacters[2] = "Lanidrac";
            sideCharacters[3] = "Luria"; 

        }
    }

}