﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace Week7Game
{
    internal class Location
    {
        public string Name { get; private set; }
        public string Task { get; private set; }

        public Location (string name, string task)
        {
            Name = name;
            Task = task;
        }
    }
}
