﻿// See https://aka.ms/new-console-template for more information

using Week7Game;

new Game();
