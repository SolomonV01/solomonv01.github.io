﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace Week7Game
{
    internal class Characters
    {
        public string Name { get; protected set; }

        public Characters() { }

        public Characters (string name)
        {
            Name = name;
        }

        public string Greeting()
        {
            return $"Hello {this.Name}";
        }

    }
}

