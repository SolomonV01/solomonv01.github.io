﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace Week7Game
{
    internal class Player:Characters
    {
        private List<Item> inventory = new List<Item>() { };

        public Player()
        {
            Name = "Player one";
        }

        public void UpdateName (string name)
        {
            Name = name;
        }

        public string UpdateInventory (Item i)
        {
            string result;
            if (inventory.Contains(i))
            {
                result = "you already have this item";
            }
            else
            {
                inventory.Add(i);
                result = $"{i.Name} item has been collected";
            }
            return result;
        }

        public string DisplayInventory()
        {
            StringBuilder result = new StringBuilder();
            foreach(var item in this.inventory)
            {
                result.Append($"{item.Name}\n");
            }

            return result.ToString();
        }

        public int CheckInventory()
        {
            return this.inventory.Count;
        }
    }
}
