﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Security.Cryptography.X509Certificates;
using System.Text;
using System.Threading.Tasks;

namespace Week7Game
{
    internal class Game
    {
        private Player myPlayer = new Player();

        private List<Location> locations = new List<Location>();
        private List<Item> items = new List<Item>();
        private List<Characters> NPC = new List<Characters>();
        private string gameData = "GameData.txt";


        public Game()
        {
            SetupPLayer();
        }

        public void LoadGame()
        {
            foreach(var element in File.ReadAllLines(gameData))
            {
                var fields = element.Split(';');
                locations.Add(new Location(fields[0], fields[1]));
                items.Add(new Item(fields[2]));
                NPC.Add(new NPC(fields[3]));
            }
        }

        public void SetupPLayer()
        {
            Console.WriteLine("Welcome to Middle earth");
            while (true)
            {
                Console.WriteLine("Choose your adventurer name:");
                try
                {
                    myPlayer.UpdateName(Console.ReadLine());
                }
                catch
                {

                }

                Console.WriteLine($"You chose: {myPlayer.Name}.\n Press\"n\" key to change it and any other key to continue");

                ConsoleKeyInfo input = Console.ReadKey(true);

                if (input.Key != ConsoleKey.N)
                {
                    break;
                }
                Console.Clear();
            }
            
        }

        public bool Play()
        {
            int choice = 0;
            while (true)
            {
                Console.Clear();
                Console.WriteLine("You arrive at a cross roads,you can go to:");
                for(int i = 0; i < locations.Count; i++)
                {
                    Console.WriteLine($"{i + 1}:{locations[i].Name}");

                }
                Console.WriteLine("Enter number to select a location to travel to ");

            }

            try
            {
                choice= Convert.ToInt32(Console.ReadLine());
                choice--;
                if (choice >= 0 && choice < locations.Count)
                {
                    break;
                }
                else
                {
                    throw new Exception();
                }
            }catch (Exception)
            {
                Console.WriteLine("Not a valid choice press any key to try again");
                Console.ReadKey(true);
            }
            Travel(Location[choice], choice);
            if (myPlayer.CheckInventory() == locations.Count)
            {
                return false;
            }
            return true;
        }

        public void Travel(Location l,int choice)
        {

            while (true)
            {
                Console.Clear();
                Console.WriteLine(NPC[choice].Greeting());
                Console.WriteLine($"Welcome to {l.Name}!\n{l.Task}");
                Console.WriteLine("Y to help, N to Ignore");

                ConsoleKeyInfo input = Console.ReadKey(true);
                if (input.Key == ConsoleKey.N)
                {
                    Console.WriteLine("Suit yourself");
                    break;
                }else if(input.Key == ConsoleKey.Y)
                {
                    Console.WriteLine(myPlayer.UpdateInventory(items[choice]));
                    break;
                }

                else
                {
                    Console.WriteLine("I didnt recognice that choice press another key to try again");
                    Console.ReadKey(true);
                }

            }
        }

        public void GameEnd()
        {
            Console.Clear();
            Console.WriteLine("Congrats you finished the game");

        }
    }

}
