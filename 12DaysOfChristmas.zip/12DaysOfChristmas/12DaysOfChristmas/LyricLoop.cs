﻿using System;
using System.Collections.Generic;
using System.Text;

namespace _12DaysOfChristmas
{
    internal class LyricLoop
    {
        LoopLyric MyLyric = new LoopLyric();

        public LyricLoop()
        {


        }

        public string Run(string[] list)
        {
            string[] DataChristmas = new string[12];




        StringBuilder result = new StringBuilder();

            for(int i = 0; i<list.Length; i++)
            {
                DataChristmas[i] = MyLyric.Presents[i];
                Console.WriteLine($"On the {MyLyric.DataArray[i]} My true love gave to me {DataChristmas}");

            }
            
            
            

        }

     

















    }
}
