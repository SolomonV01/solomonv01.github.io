﻿using System;
using System.Collections.Generic;
using System.Text;

namespace _12DaysOfChristmas
{
    internal class LoopLyric
    {
        public string[] DataArray = new string[]
        {
            "first" +
            "second" +
            "third" +
            "fourth" +
            "fifth" +
            "sixth" +
            "seventh" + 
            "eigth" +
            "ninth" +
            "tenth" +
            "eleventh" + 
            "twevlth" 
   
        };

        public string[] Presents = new string[]
       {
           "a partridge in a pear tree" +
           "two turtle doves" +
           "three French hens" +
           "Four calling birds" +
           "five golden rings" +
           "geese a laying" +
           "seven swans a swimming" +
           "eight maids a milking" +
           "nine ladies dancing" +
           "ten lords a leaping" +
           "eleven pipers piping" +
           "twelve drummers drumming"

       };









    }
}
