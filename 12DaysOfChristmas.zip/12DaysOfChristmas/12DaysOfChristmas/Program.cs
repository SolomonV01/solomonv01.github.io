﻿using System;

namespace _12DaysOfChristmas
{
    internal class Program
    {
       


    }
}
